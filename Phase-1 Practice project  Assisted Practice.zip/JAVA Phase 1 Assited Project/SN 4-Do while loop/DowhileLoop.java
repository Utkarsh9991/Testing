package corejava;

public class DowhileLoop {

	public static void main(String[] args) {
		System.out.println("Using a do-while loop:");
        int k = 1;
        do {
            System.out.println(k);
            k++;
        } 
        while (k <= 9);

	}

}
