package corejava;

class ClassObjConstrcutor {
    String name;
    int age;

    // Constructor
    public ClassObjConstrcutor(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Method
    public void introduce() {
        System.out.println("Hello, I'm " + name + " and I'm " + age + " years old.");
    }

    public static void main(String[] args) {
        // Creating objects (instances) of the Person class
    	ClassObjConstrcutor person1 = new ClassObjConstrcutor("Utkarsh", 24);
    	ClassObjConstrcutor person2 = new ClassObjConstrcutor("Bob", 40);

        // Calling a method on each object
        person1.introduce();
        person2.introduce();
    }
   
}
//---------------------------------------------------------------------------------------------------
//We have a ClassObjConstrcutor class with two attributes (name and age).
//The ClassObjConstrcutor class has a constructor that initializes the name and age when a ClassObjConstrcutor object is created.
//The introduce method displays information about the person.
//In the main method, we create two Person objects (person1 and person2) using the constructor and provide values for name and age.
//We call the introduce method on each object, which prints their information

