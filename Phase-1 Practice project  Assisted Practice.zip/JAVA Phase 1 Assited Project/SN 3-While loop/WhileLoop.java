package corejava;

public class WhileLoop {

	public static void main(String[] args) {
		
		System.out.println("Using a while loop:");
        int j = 1;
        while (j <= 5) {
            System.out.println(j);
            j++;
	}
  }

}
