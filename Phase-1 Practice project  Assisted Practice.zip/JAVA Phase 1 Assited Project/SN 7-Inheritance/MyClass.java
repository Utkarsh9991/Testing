package corejava;
//------------------------Single Inheritance
class Animal {
  void eat() {
      System.out.println("Animal is eating.");
  }
}

class Dog extends Animal {
  void bark() {
      System.out.println("Dog is barking.");
  }
}
//------------------------Multilevel Inheritance

class Puppy extends Dog {
  void play() {
      System.out.println("Puppy is playing.");
  }
}

//------------------------Hierarchical Inheritance:
class Shape {
  void draw() {
      System.out.println("Drawing a shape.");
  }
}

class Circle extends Shape {
  void drawCircle() {
      System.out.println("Drawing a circle.");
  }
}

class Square extends Shape {
  void drawSquare() {
      System.out.println("Drawing a square.");
  }
}
//----------------------------Multiple Inheritance
interface A {
  void methodA();
}

interface B {
  void methodB();
}

class MyClass implements A, B {
  public void methodA() {
      System.out.println("Method A");
  }

  public void methodB() {
      System.out.println("Method B");
  }

  public static void main(String[] args) {
      Animal animal = new Animal();
      animal.eat();

      Dog dog = new Dog();
      dog.eat();
      dog.bark();

      Puppy puppy = new Puppy();
      puppy.eat();
      puppy.bark();
      puppy.play();

      Circle circle = new Circle();
      circle.draw();
      circle.drawCircle();

      Square square = new Square();
      square.draw();
      square.drawSquare();

      MyClass myClass = new MyClass();
      myClass.methodA();
      myClass.methodB();
  }
}

