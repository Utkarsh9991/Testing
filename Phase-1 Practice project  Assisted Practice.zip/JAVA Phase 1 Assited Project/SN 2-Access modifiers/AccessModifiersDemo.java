package corejava;

public class AccessModifiersDemo {
	    public int publicVar = 10; // Public variable

	    private int privateVar = 20; // Private variable

	    protected int protectedVar = 30; // Protected variable

	    public void accessPublicVar() {
	        System.out.println("Accessing Public Variable: " + publicVar);
	    }

	    protected void accessProtectedVar() {
	        System.out.println("Accessing Protected Variable: " + protectedVar);
	    }

	    public static void main(String[] args) {
	        AccessModifiersDemo demo = new AccessModifiersDemo();

	        demo.accessPublicVar(); 

	        System.out.println("Accessing Private Variable within the same class: " + demo.privateVar);

	        demo.accessProtectedVar(); 
	    }
	}

