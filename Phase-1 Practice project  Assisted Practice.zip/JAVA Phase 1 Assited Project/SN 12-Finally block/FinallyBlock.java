package corejava;

public class FinallyBlock {
	public static void main(String args[]){  
//----------------------Without Exception
		try{
		int number=25/5;  
		System.out.println(number);  
		  }  
		catch(NullPointerException e)
		  {
			System.out.println(e);
		  }  
		finally
			{
	System.out.println("The Execution of final block always happen ");
			}  
		System.out.println("after final the rest of the code....");
		  } 
		}  

//------------------------------With Exception
/*
	try{
	int number=5/0;  
	System.out.println(number);  
	  }  
	catch(NullPointerException e)
	  {
		System.out.println(e);
	  }  
	finally
	  {
System.out.println("finally block is always executed");
	  }  
	System.out.println("then rest of the code...");  
	  } 
}




*/
//---------------------------------Exception handled
/*
 try{
		int number=25/0;  
		System.out.println(number);  
		  }  
		catch(ArithmeticException e)
		  {
			System.out.println(e);
			  }  
		finally
		  {
	System.out.println("finally block is always executed");
			  }  
		System.out.println("rest of the code...");  
		  }  
}

 */
