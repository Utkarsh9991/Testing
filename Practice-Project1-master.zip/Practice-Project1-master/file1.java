class new {
	public static void main(String[]args)
	{
	Sytem.out.println("Hello");
	}
	}
