class login{
public static void main(String[]args){
Sytem.out.println("This is login page");
}
}
