import  flask
import num.py
a=[1,4,5,67,7,7]
x=min(a)
print(x)
